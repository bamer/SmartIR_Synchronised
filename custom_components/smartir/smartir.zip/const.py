# const.py
DOMAIN = "smartir"
CONF_NAME = "name"
CONF_TEMPERATURE_SENSOR = "temperature_sensor"
CONF_HUMIDITY_SENSOR = "humidity_sensor"
# … add any other constants you want to expose in the UI